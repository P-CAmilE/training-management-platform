$(function(){
	
	// $.ajax({
			// url : "/",
			// type : "Post",
			// data : {

			// },
			// dataType : "json",
			// async : false,
			// success : function(data) {
				
				// }
			// }
		// });
	
});